var searchData=
[
  ['other',['Other',['../group__lavu__misc.html',1,'']]],
  ['option_20getting_20functions',['Option getting functions',['../group__opt__get__funcs.html',1,'']]],
  ['option_20setting_20functions',['Option setting functions',['../group__opt__set__funcs.html',1,'']]]
];
