var searchData=
[
  ['dcttransformtype',['DCTTransformType',['../group__lavc__fft.html#gaeeabd062332b246d19bed36e041d2df6',1,'avfft.h']]]
];
