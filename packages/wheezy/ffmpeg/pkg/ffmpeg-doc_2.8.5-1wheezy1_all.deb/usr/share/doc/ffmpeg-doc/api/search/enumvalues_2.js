var searchData=
[
  ['dct_5fi',['DCT_I',['../group__lavc__fft.html#ggaeeabd062332b246d19bed36e041d2df6a6b14deec67dfefcbf3d873a7e55f9358',1,'avfft.h']]],
  ['dct_5fii',['DCT_II',['../group__lavc__fft.html#ggaeeabd062332b246d19bed36e041d2df6aa9d4777883f8c2a1595ded20953287e2',1,'avfft.h']]],
  ['dct_5fiii',['DCT_III',['../group__lavc__fft.html#ggaeeabd062332b246d19bed36e041d2df6a989cbc292cc725421fac1d88c167f229',1,'avfft.h']]],
  ['dft_5fc2r',['DFT_C2R',['../group__lavc__fft.html#gga58a704747daba49afa3611cea218a24ba9709deb5e8ae7c29d950d6d1fad19444',1,'avfft.h']]],
  ['dft_5fr2c',['DFT_R2C',['../group__lavc__fft.html#gga58a704747daba49afa3611cea218a24ba417b17dd8e9f755f06a9469826e4adc9',1,'avfft.h']]],
  ['dst_5fi',['DST_I',['../group__lavc__fft.html#ggaeeabd062332b246d19bed36e041d2df6aef2c0de34cd8c5582950db643ba88d53',1,'avfft.h']]]
];
