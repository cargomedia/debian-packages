var searchData=
[
  ['va_20api_20decoding',['VA API Decoding',['../group__lavc__codec__hwaccel__vaapi.html',1,'']]],
  ['vda',['VDA',['../group__lavc__codec__hwaccel__vda.html',1,'']]],
  ['vdpau_20decoder_20and_20renderer',['VDPAU Decoder and Renderer',['../group__lavc__codec__hwaccel__vdpau.html',1,'']]],
  ['version_20and_20build_20diagnostics',['Version and Build diagnostics',['../group__lavu__ver.html',1,'']]]
];
