var searchData=
[
  ['swrcontext',['SwrContext',['../group__lswr.html#ga4aa775b7fba31d2c8dc14c7b7e282863',1,'swresample.h']]]
];
