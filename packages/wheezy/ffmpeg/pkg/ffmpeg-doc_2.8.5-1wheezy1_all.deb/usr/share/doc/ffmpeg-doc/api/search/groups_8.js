var searchData=
[
  ['libavfilter_20_2d_20graph_2dbased_20frame_20editing_20library',['Libavfilter - graph-based frame editing library',['../group__lavfi.html',1,'']]],
  ['libavresample',['Libavresample',['../group__lavr.html',1,'']]],
  ['logging_20facility',['Logging Facility',['../group__lavu__log.html',1,'']]],
  ['logging_20constants',['Logging Constants',['../group__lavu__log__constants.html',1,'']]],
  ['lzo',['LZO',['../group__lavu__lzo.html',1,'']]],
  ['libpostproc',['Libpostproc',['../group__lpp.html',1,'']]],
  ['libswresample',['Libswresample',['../group__lswr.html',1,'']]],
  ['library_20version_20macros',['Library Version Macros',['../group__version__utils.html',1,'']]]
];
