var searchData=
[
  ['rounded_5fdiv',['ROUNDED_DIV',['../common_8h.html#a7a2a86492a286d6d20678da1dbb00525',1,'common.h']]],
  ['rshift',['RSHIFT',['../common_8h.html#aa79ca71ef110a498d8275cbf7aa75a93',1,'common.h']]]
];
