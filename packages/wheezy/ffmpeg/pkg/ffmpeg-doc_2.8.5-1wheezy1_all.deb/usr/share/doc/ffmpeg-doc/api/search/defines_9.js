var searchData=
[
  ['output_5fbit_5frate',['OUTPUT_BIT_RATE',['../transcode__aac_8c.html#a40d898a8dbfccabcbbff15a29924e97f',1,'transcode_aac.c']]],
  ['output_5fchannels',['OUTPUT_CHANNELS',['../transcode__aac_8c.html#a4d4855d9b709af9628540e41e5ebb925',1,'transcode_aac.c']]]
];
