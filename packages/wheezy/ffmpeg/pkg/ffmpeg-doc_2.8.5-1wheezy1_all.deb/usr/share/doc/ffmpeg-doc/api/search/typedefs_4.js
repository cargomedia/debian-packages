var searchData=
[
  ['rdftcontext',['RDFTContext',['../group__lavc__fft.html#gad6a19df0e8cfc4d67a325e4f91fd9cd9',1,'avfft.h']]],
  ['resamplecontext',['ReSampleContext',['../group__lavc__resample.html#ga0051f36cfec3437423a131c085ff5ea2',1,'avcodec.h']]]
];
