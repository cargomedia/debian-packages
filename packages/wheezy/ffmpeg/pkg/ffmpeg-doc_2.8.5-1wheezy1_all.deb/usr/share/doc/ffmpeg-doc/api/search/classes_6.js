var searchData=
[
  ['swsfilter',['SwsFilter',['../structSwsFilter.html',1,'']]],
  ['swsvector',['SwsVector',['../structSwsVector.html',1,'']]]
];
