var searchData=
[
  ['h',['h',['../structAVFilterLink.html#a1efd10db9d097b6d27054da46e06e133',1,'AVFilterLink::h()'],['../structAVSubtitleRect.html#afb3272792cfe659e9e788074d3328d3d',1,'AVSubtitleRect::h()'],['../structAVMotionVector.html#aaa41c9b570ff085251521a1198c1de9c',1,'AVMotionVector::h()']]],
  ['h264',['h264',['../unionAVVDPAUPictureInfo.html#a9b04dee7006f93e2b2cede4316d99673',1,'AVVDPAUPictureInfo']]],
  ['has_5fb_5fframes',['has_b_frames',['../structAVCodecContext.html#a686a77363668795c15c87b532cc455fa',1,'AVCodecContext']]],
  ['hash_2eh',['hash.h',['../hash_8h.html',1,'']]],
  ['header_5fbits',['header_bits',['../structAVCodecContext.html#af91d7a57d14f1cc5d5fc413755aea3f0',1,'AVCodecContext']]],
  ['height',['height',['../structAVDeviceRect.html#a0554500f55abfff27a4141b3346a93f6',1,'AVDeviceRect::height()'],['../structAVPanScan.html#a76e1fcfbecaf034b5c4d6604d602e474',1,'AVPanScan::height()'],['../structAVCodecContext.html#a0449afd803eb107bd4dbc8b5ea22e363',1,'AVCodecContext::height()'],['../structAVCodecParserContext.html#a0e64b20802c2a2fbaa998ba7ee5ecd2e',1,'AVCodecParserContext::height()'],['../structAVDVProfile.html#ad9e3fd93f735b40850fd78e73f32f7e8',1,'AVDVProfile::height()'],['../structvda__context.html#aa404ef10a896b154cd41829be525d0e3',1,'vda_context::height()'],['../structAVFrame.html#a3f89733f429c98ba5bc64373fb0a3f13',1,'AVFrame::height()'],['../demuxing__decoding_8c.html#ad12fc34ce789bce6c8a05d8a17138534',1,'height():&#160;demuxing_decoding.c']]],
  ['help',['help',['../structAVOption.html#a6c72d22b8c599e89abba088b85dfcd8a',1,'AVOption']]],
  ['hmac_2eh',['hmac.h',['../hmac_8h.html',1,'']]],
  ['hwaccel',['hwaccel',['../structAVCodecContext.html#ab1030454a58273fd5ab88679b1eed7cc',1,'AVCodecContext']]],
  ['hwaccel_5fcodec_5fcap_5fexperimental',['HWACCEL_CODEC_CAP_EXPERIMENTAL',['../group__lavc__core.html#ga6123ca58364d461679bed5c726aa0c82',1,'avcodec.h']]],
  ['hwaccel_5fcontext',['hwaccel_context',['../structAVCodecContext.html#ab222f7d747dfdceff0a76999e09648c0',1,'AVCodecContext']]],
  ['hwaccel_5fpicture_5fprivate',['hwaccel_picture_private',['../structAVFrame.html#a65f7f4bcff7f6ffb020138d839bbb3f6',1,'AVFrame']]],
  ['hardware_20accelerators_20bridge',['Hardware Accelerators bridge',['../group__lavc__codec__hwaccel.html',1,'']]],
  ['hmac',['HMAC',['../group__lavu__hmac.html',1,'']]]
];
