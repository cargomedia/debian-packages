var searchData=
[
  ['get_5futf16',['GET_UTF16',['../common_8h.html#a2665137b6cc64bb5cf491ba9f9dbd215',1,'common.h']]],
  ['get_5futf8',['GET_UTF8',['../common_8h.html#a1a2fd8cd42afb00c9f69562f52b1ae4b',1,'common.h']]]
];
