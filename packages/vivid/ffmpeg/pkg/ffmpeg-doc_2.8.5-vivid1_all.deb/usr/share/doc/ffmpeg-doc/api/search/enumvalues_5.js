var searchData=
[
  ['kvdadecodeinfo_5fasynchronous',['kVDADecodeInfo_Asynchronous',['../vda_8h.html#adc29c2ff13d900c2f185ee95427fb06ca6a3d93ff5334fd34c1a863298cbc598b',1,'vda.h']]],
  ['kvdadecodeinfo_5fframedropped',['kVDADecodeInfo_FrameDropped',['../vda_8h.html#adc29c2ff13d900c2f185ee95427fb06ca03ffb3954e167c29e46c07251920ecbf',1,'vda.h']]]
];
