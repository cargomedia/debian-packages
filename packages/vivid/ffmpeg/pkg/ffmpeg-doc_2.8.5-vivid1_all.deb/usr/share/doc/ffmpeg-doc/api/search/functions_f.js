var searchData=
[
  ['video_5fdecode_5fexample',['video_decode_example',['../decoding__encoding_8c.html#a8b416e073a13f42326e97a86ce283db1',1,'decoding_encoding.c']]],
  ['video_5fencode_5fexample',['video_encode_example',['../decoding__encoding_8c.html#a7293f14f6e6315d54331137ae883079f',1,'decoding_encoding.c']]]
];
