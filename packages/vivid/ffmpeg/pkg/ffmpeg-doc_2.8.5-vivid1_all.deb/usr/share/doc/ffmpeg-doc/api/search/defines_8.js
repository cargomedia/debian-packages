var searchData=
[
  ['nan',['NAN',['../mathematics_8h.html#a8abfcc76130f3f991d124dd22d7e69bc',1,'mathematics.h']]]
];
