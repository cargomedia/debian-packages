var searchData=
[
  ['vaapi_5fcontext',['vaapi_context',['../structvaapi__context.html',1,'']]],
  ['vda_5fcontext',['vda_context',['../structvda__context.html',1,'']]],
  ['vdpau_5frender_5fstate',['vdpau_render_state',['../structvdpau__render__state.html',1,'']]]
];
