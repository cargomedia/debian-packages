var searchData=
[
  ['volume_5fval',['VOLUME_VAL',['../filter__audio_8c.html#a925601362f35fd86bd143e81d23a5ecf',1,'filter_audio.c']]],
  ['vorbis_5fflag_5fcomment',['VORBIS_FLAG_COMMENT',['../vorbis__parser_8h.html#a837f7868aa92752a2727f6b66d9cf7ea',1,'vorbis_parser.h']]],
  ['vorbis_5fflag_5fheader',['VORBIS_FLAG_HEADER',['../vorbis__parser_8h.html#a9205506ccac8f073592f93efa841dd29',1,'vorbis_parser.h']]],
  ['vorbis_5fflag_5fsetup',['VORBIS_FLAG_SETUP',['../vorbis__parser_8h.html#a03a79f9bda327495ba1a9ad16574c583',1,'vorbis_parser.h']]]
];
