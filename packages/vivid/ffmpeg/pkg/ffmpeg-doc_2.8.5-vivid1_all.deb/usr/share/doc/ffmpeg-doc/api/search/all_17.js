var searchData=
[
  ['xvmc',['XvMC',['../group__lavc__codec__hwaccel__xvmc.html',1,'']]],
  ['xtea',['XTEA',['../group__lavu__xtea.html',1,'']]],
  ['x',['x',['../structAVDeviceRect.html#a59c84ebbf20ec757079bcad8cf6938ba',1,'AVDeviceRect::x()'],['../structAVSubtitleRect.html#a0059c986f1ee3aab45c0f62f0709621b',1,'AVSubtitleRect::x()']]],
  ['xtea_2eh',['xtea.h',['../xtea_8h.html',1,'']]],
  ['xvmc_2eh',['xvmc.h',['../xvmc_8h.html',1,'']]],
  ['xvmc_5fid',['xvmc_id',['../structxvmc__pix__fmt.html#a6cadfce3023ac1a8730e675629f21430',1,'xvmc_pix_fmt']]],
  ['xvmc_5fpix_5ffmt',['xvmc_pix_fmt',['../structxvmc__pix__fmt.html',1,'']]]
];
