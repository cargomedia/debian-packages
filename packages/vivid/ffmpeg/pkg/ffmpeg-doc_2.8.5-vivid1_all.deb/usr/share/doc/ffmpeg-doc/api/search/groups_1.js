var searchData=
[
  ['buffer_20sink_20api',['Buffer sink API',['../group__lavfi__buffersink.html',1,'']]],
  ['buffer_20source_20api',['Buffer source API',['../group__lavfi__buffersrc.html',1,'']]],
  ['base64',['Base64',['../group__lavu__base64.html',1,'']]],
  ['blowfish',['Blowfish',['../group__lavu__blowfish.html',1,'']]]
];
