var searchData=
[
  ['utility_20functions',['Utility functions',['../group__lavc__misc.html',1,'']]],
  ['utility_20functions',['Utility functions',['../group__lavf__misc.html',1,'']]]
];
