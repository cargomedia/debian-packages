var searchData=
[
  ['buffer_5fdata',['buffer_data',['../structbuffer__data.html',1,'']]]
];
