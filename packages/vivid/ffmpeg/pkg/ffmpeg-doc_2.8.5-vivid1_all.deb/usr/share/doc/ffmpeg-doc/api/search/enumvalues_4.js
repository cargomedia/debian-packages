var searchData=
[
  ['idft_5fc2r',['IDFT_C2R',['../group__lavc__fft.html#gga58a704747daba49afa3611cea218a24baadf7acc2f968f4345998fef751bedc8c',1,'avfft.h']]],
  ['idft_5fr2c',['IDFT_R2C',['../group__lavc__fft.html#gga58a704747daba49afa3611cea218a24ba5b4ae99ec831a4fc29d1a4bac635cdb6',1,'avfft.h']]]
];
