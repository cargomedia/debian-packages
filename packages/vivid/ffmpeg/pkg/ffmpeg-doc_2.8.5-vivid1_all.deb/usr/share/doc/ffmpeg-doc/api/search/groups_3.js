var searchData=
[
  ['deprecation_20guards',['Deprecation guards',['../group__depr__guards.html',1,'']]],
  ['direct3d11',['Direct3D11',['../group__lavc__codec__hwaccel__d3d11va.html',1,'']]],
  ['dxva2',['DXVA2',['../group__lavc__codec__hwaccel__dxva2.html',1,'']]],
  ['decoding',['Decoding',['../group__lavc__decoding.html',1,'']]],
  ['demuxers',['Demuxers',['../group__lavf__codec.html',1,'']]],
  ['demuxing',['Demuxing',['../group__lavf__decoding.html',1,'']]],
  ['data_20structures',['Data Structures',['../group__lavu__data.html',1,'']]]
];
