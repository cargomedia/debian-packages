var searchData=
[
  ['xvmc',['XvMC',['../group__lavc__codec__hwaccel__xvmc.html',1,'']]],
  ['xtea',['XTEA',['../group__lavu__xtea.html',1,'']]]
];
