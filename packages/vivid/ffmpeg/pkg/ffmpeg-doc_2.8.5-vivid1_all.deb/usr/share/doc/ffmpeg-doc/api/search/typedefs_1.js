var searchData=
[
  ['dctcontext',['DCTContext',['../group__lavc__fft.html#ga904cbe02e46b560fd98d172fdb27c845',1,'avfft.h']]]
];
